
package com.example.inventorytracker

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val database = DatabaseHelper(this)

        setContent {
            MaterialTheme {
                InventoryApp(database)
            }
        }
    }
}

@Composable
fun InventoryApp(db: DatabaseHelper) {
    val context = LocalContext.current

    var loggedIn by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var itemName by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var editId by remember { mutableStateOf<Int?>(null) }
    var message by remember { mutableStateOf("") }
    var inventory by remember { mutableStateOf(emptyList<InventoryItem>()) }
    var pendingAlert by remember { mutableStateOf<String?>(null) }

    fun refresh() {
        inventory = db.getItems()
    }

    fun sendAlert(item: String) {
        if (phone.isBlank()) {
            message = "Enter a phone number to receive alerts."
            return
        }

        if (!context.packageManager.hasSystemFeature(
                PackageManager.FEATURE_TELEPHONY_MESSAGING
            )) {
            message = "SMS is not supported on this device."
            return
        }

        try {
            @Suppress("DEPRECATION")
            val sms = SmsManager.getDefault()
            sms.sendTextMessage(
                phone, null,
                "Inventory alert: $item is out of stock.",
                null, null
            )
            message = "SMS send requested."
        } catch (e: Exception) {
            message = "Item saved, but SMS could not be sent."
        }
    }

    val smsPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        val item = pendingAlert
        pendingAlert = null

        if (granted && item != null) {
            sendAlert(item)
        } else if (!granted) {
            message = "SMS permission denied. Inventory still works."
        }
    }

    fun checkSms(item: String) {
        if (phone.isBlank()) {
            message = "Item saved. Add a phone number for alerts."
            return
        }

        if (ContextCompat.checkSelfPermission(
                context, Manifest.permission.SEND_SMS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            sendAlert(item)
        } else {
            pendingAlert = item
            smsPermission.launch(Manifest.permission.SEND_SMS)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            "Inventory Tracker",
            style = MaterialTheme.typography.headlineMedium
        )

        if (!loggedIn) {
            OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Username") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    if (db.login(username, password)) {
                        loggedIn = true
                        refresh()
                        message = "Login successful."
                    } else {
                        message = "Incorrect username or password."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Login")
            }

            OutlinedButton(
                onClick = {
                    message = if (db.register(username, password)) {
                        "Account created. You can now log in."
                    } else {
                        "Use a unique username and password of 6+ characters."
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Create Account")
            }
        } else {
            Text("Welcome, $username")

            OutlinedTextField(
                value = itemName,
                onValueChange = { itemName = it },
                label = { Text("Item Name") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = quantity,
                onValueChange = { quantity = it },
                label = { Text("Quantity") },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Number
                ),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone Number for SMS Alerts") },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone
                ),
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    val qty = quantity.toIntOrNull()

                    if (itemName.isBlank() || qty == null || qty < 0) {
                        message = "Enter a valid item name and quantity."
                    } else {
                        val saved = if (editId == null) {
                            db.addItem(itemName, qty)
                        } else {
                            db.updateItem(editId!!, itemName, qty)
                        }

                        if (saved) {
                            val savedName = itemName
                            refresh()
                            itemName = ""
                            quantity = ""
                            editId = null
                            message = "Item saved successfully."

                            if (qty == 0) checkSms(savedName)
                        } else {
                            message = "Could not save item."
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (editId == null) "Add Item" else "Update Item")
            }

            HorizontalDivider()

            Text(
                "My Inventory",
                style = MaterialTheme.typography.titleLarge
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(inventory, key = { it.id }) { item ->
                    Card {
                        Column(Modifier.padding(8.dp)) {
                            Text(item.name)
                            Text("Quantity: ${item.quantity}")

                            TextButton(onClick = {
                                editId = item.id
                                itemName = item.name
                                quantity = item.quantity.toString()
                            }) {
                                Text("Edit")
                            }

                            TextButton(onClick = {
                                db.deleteItem(item.id)
                                refresh()
                                message = "Item deleted."
                            }) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }

            OutlinedButton(
                onClick = {
                    loggedIn = false
                    password = ""
                    editId = null
                    message = "Logged out."
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Logout")
            }
        }

        if (message.isNotBlank()) {
            Text(message, color = MaterialTheme.colorScheme.primary)
        }
    }
}

