

package com.example.inventorytracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class InventoryItem(val id: Int, val name: String, val quantity: Int)

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "inventory.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT UNIQUE, salt TEXT, password TEXT)")
        db.execSQL("CREATE TABLE inventory (id INTEGER PRIMARY KEY, name TEXT, quantity INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        // Future database upgrades
    }

    // Protect passwords using a salted hash.
    private fun hash(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 120000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                .generateSecret(spec).encoded
                .joinToString("") { "%02x".format(it) }
        } finally {
            spec.clearPassword()
        }
    }

    fun register(username: String, password: String): Boolean {
        if (username.isBlank() || password.length < 6) return false
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val values = ContentValues().apply {
            put("username", username.trim())
            put("salt", salt.joinToString("") { "%02x".format(it) })
            put("password", hash(password, salt))
        }
        return writableDatabase.insert("users", null, values) != -1L
    }

    fun login(username: String, password: String): Boolean {
        readableDatabase.rawQuery(
            "SELECT salt, password FROM users WHERE username=?",
            arrayOf(username.trim())
        ).use {
            if (!it.moveToFirst()) return false
            val salt = it.getString(0).chunked(2)
                .map { part -> part.toInt(16).toByte() }.toByteArray()
            return MessageDigest.isEqual(
                hash(password, salt).toByteArray(),
                it.getString(1).toByteArray()
            )
        }
    }

    fun getItems(): List<InventoryItem> {
        val list = mutableListOf<InventoryItem>()
        readableDatabase.rawQuery(
            "SELECT id, name, quantity FROM inventory", null
        ).use {
            while (it.moveToNext())
                list.add(InventoryItem(it.getInt(0), it.getString(1), it.getInt(2)))
        }
        return list
    }

    fun addItem(name: String, quantity: Int): Boolean {
        if (name.isBlank() || quantity < 0) return false
        val values = ContentValues().apply {
            put("name", name.trim())
            put("quantity", quantity)
        }
        return writableDatabase.insert("inventory", null, values) != -1L
    }

    fun updateItem(id: Int, name: String, quantity: Int): Boolean {
        if (name.isBlank() || quantity < 0) return false
        val values = ContentValues().apply {
            put("name", name.trim())
            put("quantity", quantity)
        }
        return writableDatabase.update(
            "inventory", values, "id=?", arrayOf(id.toString())
        ) > 0
    }

    fun deleteItem(id: Int): Boolean =
        writableDatabase.delete(
            "inventory", "id=?", arrayOf(id.toString())
        ) > 0
}
